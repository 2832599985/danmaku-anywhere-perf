import{aH as a}from"./service-CtDL4LpF.js";const t=a(),r=a(),n={PURGE_DANMAKU:"purge-danmaku"};export{n as a,t as c,r};
